/**
 * @param {string} msg
 * @param {string} type
 * @returns {string} 
 */
const setAlert = (msg, type = "danger") => {
    return `<p class="alert alert-${type} d-flex justify-content-between">${msg}<button data-bs-dismiss="alert" class="btn-close"></button></p>`;
};

/**
 * @param {string} key
 * @returns {Array|false}
 */
const getLSData = (key) => {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : false;
};
/**
 * @param {string} key
 * @param {Object} value
 */
const createLSData = (key, value) => {
    const existing = getLSData(key) || [];
    existing.push(value);
    localStorage.setItem(key, JSON.stringify(existing));
};
/**
 * @param {string} key 
 * @param {Array} array 
 */
const updateLSData = (key, array) => {
    localStorage.setItem(key, JSON.stringify(array));
};
/**
 * @param {string} key 
 * @param {string} id 
 */
const removeLSData = (key, id) => {
    const data = getLSData(key);
    if (!data) return;
    const filtered = data.filter(item => item.id !== id);
    updateLSData(key, filtered);
};

/**
 * @param {Object} data
 */
const isValidPost = (data) => {
    return data.aname && data.aphoto && data.pcontent && data.pdate;
};
