const postForm = document.getElementById('post_add_form');
const msg = document.querySelector('.msg');
const allPosts = document.querySelector('.all-post');
const editPost = document.getElementById('edit_post');
postForm.onsubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());
    const { aname, aphoto, pcontent, pdate, pphoto } = data;

    if (!aname || !aphoto || !pcontent || !pdate) {
        msg.innerHTML = setAlert('تمام فیلدهای ضروری را پر کنید!');
        return;
    }
    const id = `${Math.floor(Math.random() * 1000)}_${Date.now()}`;
    const newPost = { ...data, id };

    createLSData('ins_post', newPost);
    e.target.reset();
    getAllPosts();
};
const getAllPosts = () => {
    const posts = getLSData('ins_post');
    let list = '';

    if (!posts || posts.length === 0) {
        allPosts.innerHTML = `<div class="card shadow-sm text-center mt-3"><div class="card-body">هیچ پستی یافت نشد</div></div>`;
        return;
    }
    posts.reverse().forEach(item => {
        list += `
        <div class="post">
            <div class="info">
                <div class="user">
                    <div class="profile-pic">
                        <img src="${item.aphoto}" alt="">
                    </div>
                    <p class="username">${item.aname}</p>
                </div>
                <div class="dropdown">
                    <a class="dropdown-toggle" href="#" data-bs-toggle="dropdown">
                        <i class="fas fa-ellipsis-h"></i>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item post_edit" data-id="${item.id}" data-bs-toggle="modal" data-bs-target="#edit-modal">ویرایش</a></li>
                        <li><a class="dropdown-item post_delete" data-id="${item.id}">حذف</a></li>
                    </ul>
                </div>
            </div>
            <img src="${item.pphoto}" class="post-image" alt="">
            <div class="post-content">
                <div class="reaction-wrapper">
                    <img src="assets/img/like.PNG" class="icon" alt="">
                    <img src="assets/img/comment.PNG" class="icon" alt="">
                    <img src="assets/img/send.PNG" class="icon" alt="">
                    <img src="assets/img/save.PNG" class="save icon" alt="">
                </div>
                <p class="likes">89 likes</p>
                <p class="description"><span>${item.aname}</span> ${item.pcontent}</p>
                <p class="post-time">${item.pdate}</p>
            </div>
            <div class="comment-wrapper">
                <img src="assets/img/smile.PNG" class="icon" alt="">
                <input type="text" class="comment-box" placeholder="نظر بنویسید">
                <button class="comment-btn">ارسال</button>
            </div>
        </div>
        `;
    });

    allPosts.innerHTML = list;
};
allPosts.onclick = (e) => {
    const target = e.target;
    const id = target.getAttribute('data-id');

    if (target.classList.contains('post_edit')) {
        const posts = getLSData('ins_post');
        const post = posts.find(item => item.id === id);
        editPost.innerHTML = `
            <input type="hidden" name="id" value="${post.id}">
            <div class="my-3">
                <label>نام نویسنده</label>
                <input name="aname" type="text" value="${post.aname}" class="form-control">
            </div>
            <div class="my-3">
                <label>عکس پروفایل</label>
                <input name="aphoto" type="text" value="${post.aphoto}" class="form-control">
            </div>
            <div class="my-3">
                <label>متن پست</label>
                <textarea name="pcontent" class="form-control">${post.pcontent}</textarea>
            </div>
            <div class="my-3">
                <label>عکس پست</label>
                <input name="pphoto" type="text" value="${post.pphoto}" class="form-control">
            </div>
            <div class="my-3">
                <label>تاریخ پست</label>
                <input name="pdate" type="date" value="${post.pdate}" class="form-control">
            </div>
            <input type="submit" class="btn btn-primary w-100" value="بروزرسانی پست">
        `;
    }
    if (target.classList.contains('post_delete')) {
        if (confirm('آیا مطمئن هستید که می‌خواهید این پست را حذف کنید؟')) {
            const posts = getLSData('ins_post');
            const updatedPosts = posts.filter(item => item.id !== id);
            updateLSData('ins_post', updatedPosts);
            getAllPosts();
        }
    }
};
editPost.onsubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const updatedData = Object.fromEntries(formData.entries());
    const posts = getLSData('ins_post');
    const index = posts.findIndex(item => item.id === updatedData.id);
    posts[index] = updatedData;
    updateLSData('ins_post', posts);
    getAllPosts();
};

getAllPosts();
